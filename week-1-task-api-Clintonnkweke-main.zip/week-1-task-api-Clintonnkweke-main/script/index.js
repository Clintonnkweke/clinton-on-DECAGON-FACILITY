
    const url = "https://swapi.dev/api/people/?format=json";
        fetch(url,{
            type:"POST",
        }).then(response =>  response.json())
        .then((data)=>{
            console.log(data)
            var obj = data.results  
            var arr = ["1-old.jpg","1.png","2.jpg","2.png","3.png","3.jpg","4.jpg","6.jpg","7.jpg","agent.jpg","agent2.jpg"] 
            //   var obj = data
           obj.forEach((item,index)=>{
            var height = item.height;
            var gender = item.gender;
            var names = item.name;
            document.getElementById("name").innerHTML+=`<li id="${gender}" title="${height}" type="${names}" onclick="loadAll(this)" > ${names} <img src="image/${arr[index]}" width="100" height="100" style="border-radius:100px">           
                </li>`
            console.log(names)
           
           })
    }).catch(error=>console.log(error))
    var element = document.querySelector("#con");
    var container = document.querySelector(".des");  
        var  loadAll = (x) => {
            var height = x.title
            var gender = x.id
            var names = x.type
                
            container.style.display="flex"
            var val= [`Name:  ${names}`,`Gender: ${gender}`,`Height: ${height}`]
            for (let index = 0; index < val.length; index++) {
                let value_of=val[index];      
                var li = document.createElement("li");
                var node = document.createTextNode(value_of);
                li.className="re";
                li.appendChild(node);
                element.appendChild(li);       
       }
    }
    var remove = document.getElementById("close").addEventListener("click", ()=>{
        container.style.display="none"  

        var child = document.getElementsByClassName("re")[0];
        var child2 = document.getElementsByClassName("re")[1];
        var child3 = document.getElementsByClassName("re")[2];
        element.removeChild(child);
        element.removeChild(child2);
        element.removeChild(child3);





    })


